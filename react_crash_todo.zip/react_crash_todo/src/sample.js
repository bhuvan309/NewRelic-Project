import React from 'react';

import './App.css';

class App extends React.Component {
  test() {
    return <p>This is a test class</p>
  }
  render() {
    let name = {
      firstname: 'Bhuvan',
      lastname: 'Sharma'
    }

    return (
      <React.Fragment>
        <h3>React Tutorial</h3>
        <input type='text' id='fname' value={name.firstname}></input>
        <p>Welcome {name.firstname} {name.lastname}</p>
        <div class='App-logo'>
          
          <span>{this.test()}</span>
        </div>

      </React.Fragment>
    );
  }
}

export default App;
